# Issue Tracker: Comments Service

## Issue

Our studio's internal issue tracker lets team members discuss bugs in comment threads. Since the last release, the QA team has reported:

- Comment edits look like they work, but the old text comes back.
- Issue reporters can rewrite other people's comments on their issues.
- Deleted comments still show up in the thread, and the issue's comment count still includes them.

Fix the service so it follows the API contract below.

## About the service

A small JSON API. Members comment on issues, edit their own comments, and delete comments. Deleting is a soft delete: the row stays in the database with `is_deleted = true` and the comment disappears from the API.

There is no frontend and no login flow. The caller identifies themselves with the `X-User-Id` header.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
```

## Running the tests

```bash
./t                                         # whole suite
./t tests/test_comments.py::test_create_comment_and_list
./t -k edit                                 # by name
```

`./t` runs pytest with any arguments you pass and appends a one-line summary to `../test_runs.log`.

## Rules

- Comment bodies have leading and trailing whitespace trimmed before they are validated and saved. A body that is empty after trimming counts as missing. Maximum length is 1000 characters.
- Only a comment's author can edit it. Nobody else can, including the issue's reporter and admins.
- A comment can be deleted by its author or by an admin (`is_admin = true`). The issue's reporter cannot delete other people's comments.
- Deleted comments behave as if they do not exist: they are not listed, not counted, and editing or deleting them again returns `404 comment not found`.
- Comments cannot be added to a closed issue.

## API contract

All endpoints live under `/api/`, accept and return JSON, and require the `X-User-Id` header. Errors always have the body `{"error": "<message>"}` with the exact message listed below. When a request has several problems, the checks run in the order listed, and the first failing check decides the response.

Every endpoint starts with: `401` `authentication required` when `X-User-Id` is missing, is not a number, or does not match a member.

A comment is returned as:

```json
{"id": 1, "issue": 4, "author": 2, "body": "Text", "edited": false, "created_at": "<ISO 8601>", "updated_at": "<ISO 8601>"}
```

### GET /api/issues/{id}/

- Success: `200` with `{"id", "title", "status": "open" | "closed", "reporter", "created_at", "comment_count"}`. `comment_count` counts the issue's comments that are not deleted.
- Errors: `404` `issue not found`

### GET /api/issues/{id}/comments/

- Success: `200` with the issue's comments that are not deleted, oldest first (by `created_at`, ties by `id` lowest first)
- Errors: `404` `issue not found`

### POST /api/issues/{id}/comments/

- Required fields: `body`
- Success: `201` with the new comment (`edited` is false)
- Errors, in order:
  - `404` `issue not found`
  - `409` `issue is closed`
  - `400` `body is required` or `body must be at most 1000 characters`

### PATCH /api/comments/{id}/

Edit a comment's body. The change is saved, and the comment is marked `edited = true`.

- Required fields: `body`
- Success: `200` with the updated comment
- Errors, in order:
  - `404` `comment not found`
  - `403` `forbidden` when the caller is not the comment's author
  - `400` `body is required` or `body must be at most 1000 characters`

### DELETE /api/comments/{id}/

- Success: `204` with no body
- Errors, in order:
  - `404` `comment not found`
  - `403` `forbidden` when the caller is neither the comment's author nor an admin
