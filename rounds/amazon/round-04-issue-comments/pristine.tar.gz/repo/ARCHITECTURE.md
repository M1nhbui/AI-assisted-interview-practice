# Architecture

```
config/                 Django project: settings, root URLs
tracker/
  models.py             Member, Issue, Comment (with an extra `visible` manager)
  serializers.py        CommentSerializer (input validation and output), IssueSerializer
  views.py              one APIView per URL; runs the checks in the README order
  urls.py               routes under /api/
  auth.py               reads X-User-Id; edit and delete permission checks
  selectors.py          read queries: find an issue or comment, list and count comments
  services.py           writes: add a comment, soft-delete a comment
tests/                  pytest-django tests and shared fixtures (conftest.py)
```

## Models

- `Member`: `username`, `is_admin`.
- `Issue`: `title`, `status` (`open` or `closed`), `reporter` (a Member), `created_at`.
- `Comment`: `issue`, `author`, `body`, `edited`, `is_deleted`, `created_at`, `updated_at`.
  - `Comment.objects` returns every row, including deleted ones.
  - `Comment.visible` returns only rows with `is_deleted = false`.

## Request flows

- Add a comment: auth, `selectors.find_issue`, closed check, `CommentSerializer` validates `body`, `services.add_comment` saves it.
- Edit a comment: auth, `selectors.find_comment`, `auth.can_edit_comment`, `CommentSerializer` bound to the comment (partial update) validates the new body, then the change is saved with `edited = true`.
- Delete a comment: auth, `selectors.find_comment`, `auth.can_delete_comment`, `services.soft_delete_comment`.
- List comments and the issue's `comment_count` both come from `selectors.comments_for_issue`.
