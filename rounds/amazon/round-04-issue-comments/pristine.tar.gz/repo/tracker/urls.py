from django.urls import path

from .views import CommentDetailView, IssueCommentsView, IssueDetailView

urlpatterns = [
    path("issues/<int:issue_id>/", IssueDetailView.as_view(), name="issue-detail"),
    path(
        "issues/<int:issue_id>/comments/",
        IssueCommentsView.as_view(),
        name="issue-comments",
    ),
    path("comments/<int:comment_id>/", CommentDetailView.as_view(), name="comment-detail"),
]
