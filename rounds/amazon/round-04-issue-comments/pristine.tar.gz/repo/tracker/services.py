from .models import Comment


def add_comment(issue, author, body):
    return Comment.objects.create(issue=issue, author=author, body=body)


def soft_delete_comment(comment):
    Comment.objects.filter(pk=comment.pk).update(is_deleted=True)
