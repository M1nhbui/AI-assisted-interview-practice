from django.db import models
from django.utils import timezone


class Member(models.Model):
    username = models.CharField(max_length=50, unique=True)
    is_admin = models.BooleanField(default=False)

    def __str__(self):
        return self.username


class Issue(models.Model):
    STATUS_OPEN = "open"
    STATUS_CLOSED = "closed"
    STATUS_CHOICES = [(STATUS_OPEN, "Open"), (STATUS_CLOSED, "Closed")]

    title = models.CharField(max_length=200)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_OPEN)
    reporter = models.ForeignKey(
        Member, related_name="reported_issues", on_delete=models.CASCADE
    )
    created_at = models.DateTimeField(default=timezone.now)

    @property
    def is_closed(self):
        return self.status == self.STATUS_CLOSED

    def __str__(self):
        return self.title


class VisibleCommentManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)


class Comment(models.Model):
    issue = models.ForeignKey(Issue, related_name="comments", on_delete=models.CASCADE)
    author = models.ForeignKey(Member, related_name="comments", on_delete=models.CASCADE)
    body = models.TextField()
    edited = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    objects = models.Manager()
    visible = VisibleCommentManager()

    def __str__(self):
        return f"Comment {self.pk} on issue {self.issue_id}"
