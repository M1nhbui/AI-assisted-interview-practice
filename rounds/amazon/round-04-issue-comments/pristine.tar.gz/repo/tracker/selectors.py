from .models import Comment, Issue


def find_issue(issue_id):
    return Issue.objects.filter(pk=issue_id).first()


def find_comment(comment_id):
    return Comment.visible.select_related("issue").filter(pk=comment_id).first()


def comments_for_issue(issue):
    return issue.comments.select_related("author").order_by("created_at", "id")


def comment_count(issue):
    return comments_for_issue(issue).count()
