from rest_framework import serializers

from .models import Comment, Issue
from .selectors import comment_count

BODY_ERRORS = {
    "required": "body is required",
    "null": "body is required",
    "blank": "body is required",
    "max_length": "body must be at most 1000 characters",
}


class CommentSerializer(serializers.ModelSerializer):
    body = serializers.CharField(
        max_length=1000, trim_whitespace=False, error_messages=BODY_ERRORS
    )

    class Meta:
        model = Comment
        fields = ["id", "issue", "author", "body", "edited", "created_at", "updated_at"]
        read_only_fields = ["id", "issue", "author", "edited", "created_at", "updated_at"]


class IssueSerializer(serializers.ModelSerializer):
    comment_count = serializers.SerializerMethodField()

    class Meta:
        model = Issue
        fields = ["id", "title", "status", "reporter", "created_at", "comment_count"]

    def get_comment_count(self, issue):
        return comment_count(issue)
