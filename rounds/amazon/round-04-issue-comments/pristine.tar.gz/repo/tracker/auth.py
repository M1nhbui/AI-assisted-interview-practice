from .models import Member

USER_HEADER = "X-User-Id"


def resolve_member(request):
    raw = request.headers.get(USER_HEADER, "").strip()
    if not raw.isdigit():
        return None
    return Member.objects.filter(pk=int(raw)).first()


def can_edit_comment(member, comment):
    return member.id in (comment.author_id, comment.issue.reporter_id)


def can_delete_comment(member, comment):
    return member.is_admin or member.id == comment.author_id
