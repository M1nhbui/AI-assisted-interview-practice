from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .auth import can_delete_comment, can_edit_comment, resolve_member
from .selectors import comments_for_issue, find_comment, find_issue
from .serializers import CommentSerializer, IssueSerializer
from .services import add_comment, soft_delete_comment


def error(message, code):
    return Response({"error": message}, status=code)


def first_error(errors):
    messages = next(iter(errors.values()))
    return str(messages[0])


def unauthenticated():
    return error("authentication required", status.HTTP_401_UNAUTHORIZED)


class IssueDetailView(APIView):
    def get(self, request, issue_id):
        if resolve_member(request) is None:
            return unauthenticated()

        issue = find_issue(issue_id)
        if issue is None:
            return error("issue not found", status.HTTP_404_NOT_FOUND)
        return Response(IssueSerializer(issue).data)


class IssueCommentsView(APIView):
    def get(self, request, issue_id):
        if resolve_member(request) is None:
            return unauthenticated()

        issue = find_issue(issue_id)
        if issue is None:
            return error("issue not found", status.HTTP_404_NOT_FOUND)
        comments = comments_for_issue(issue)
        return Response(CommentSerializer(comments, many=True).data)

    def post(self, request, issue_id):
        member = resolve_member(request)
        if member is None:
            return unauthenticated()

        issue = find_issue(issue_id)
        if issue is None:
            return error("issue not found", status.HTTP_404_NOT_FOUND)
        if issue.is_closed:
            return error("issue is closed", status.HTTP_409_CONFLICT)

        serializer = CommentSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        comment = add_comment(
            issue=issue, author=member, body=serializer.validated_data["body"]
        )
        return Response(CommentSerializer(comment).data, status=status.HTTP_201_CREATED)


class CommentDetailView(APIView):
    def patch(self, request, comment_id):
        member = resolve_member(request)
        if member is None:
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        comment = find_comment(comment_id)
        if comment is None:
            return error("comment not found", status.HTTP_404_NOT_FOUND)
        if not can_edit_comment(member, comment):
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        if "body" not in request.data:
            return error("body is required", status.HTTP_400_BAD_REQUEST)
        serializer = CommentSerializer(comment, data=request.data, partial=True)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        comment.edited = True
        return Response(serializer.data)

    def delete(self, request, comment_id):
        member = resolve_member(request)
        if member is None:
            return unauthenticated()

        comment = find_comment(comment_id)
        if comment is None:
            return error("comment not found", status.HTTP_404_NOT_FOUND)
        if not can_delete_comment(member, comment):
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        soft_delete_comment(comment)
        return Response(status=status.HTTP_204_NO_CONTENT)
