from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from tracker.models import Comment, Issue, Member


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def make_member(db):
    def _make_member(username, **overrides):
        return Member.objects.create(username=username, **overrides)

    return _make_member


@pytest.fixture
def reporter(make_member):
    return make_member("rhea")


@pytest.fixture
def dev(make_member):
    return make_member("dev")


@pytest.fixture
def issue(reporter):
    return Issue.objects.create(title="Crash on save", reporter=reporter)


@pytest.fixture
def make_comment(db):
    def _make_comment(issue, author, body="Can reproduce on build 412.", age_minutes=0):
        return Comment.objects.create(
            issue=issue,
            author=author,
            text=body,
            created_at=timezone.now() - timedelta(minutes=age_minutes),
        )

    return _make_comment


def as_member(member):
    return {"HTTP_X_USER_ID": str(member.id)}
