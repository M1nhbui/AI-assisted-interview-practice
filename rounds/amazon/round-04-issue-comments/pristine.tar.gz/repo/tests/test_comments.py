from tracker.models import Comment, Issue

from .conftest import as_member


def comments_url(issue):
    return f"/api/issues/{issue.id}/comments/"


def test_create_comment_and_list(api_client, issue, dev):
    response = api_client.post(
        comments_url(issue), {"body": "Happens on Windows only."}, format="json", **as_member(dev)
    )

    assert response.status_code == 201
    created = response.json()
    assert created["issue"] == issue.id
    assert created["author"] == dev.id
    assert created["edited"] is False

    listing = api_client.get(comments_url(issue), **as_member(dev))
    assert listing.status_code == 200
    assert [c["body"] for c in listing.json()] == ["Happens on Windows only."]


def test_cannot_comment_on_closed_issue(api_client, reporter, dev):
    closed = Issue.objects.create(title="Old bug", reporter=reporter, status="closed")

    response = api_client.post(
        comments_url(closed), {"body": "Still seeing this."}, format="json", **as_member(dev)
    )

    assert response.status_code == 409
    assert response.json() == {"error": "issue is closed"}
    assert Comment.objects.count() == 0


def test_edit_own_comment_persists(api_client, issue, dev, make_comment):
    comment = make_comment(issue, dev, body="Fails on build 412.")

    response = api_client.patch(
        f"/api/comments/{comment.id}/", {"body": "Fails on build 413 too."}, format="json", **as_member(dev)
    )

    assert response.status_code == 200
    assert response.json()["body"] == "Fails on build 413 too."
    assert response.json()["edited"] is True
    comment.refresh_from_db()
    assert comment.body == "Fails on build 413 too."
    assert comment.edited is True


def test_reporter_cannot_edit_others_comment(api_client, issue, reporter, dev, make_comment):
    comment = make_comment(issue, dev, body="Root cause is the autosave timer.")

    response = api_client.patch(
        f"/api/comments/{comment.id}/", {"body": "Not a bug."}, format="json", **as_member(reporter)
    )

    assert response.status_code == 403
    assert response.json() == {"error": "forbidden"}
    comment.refresh_from_db()
    assert comment.body == "Root cause is the autosave timer."


def test_edit_requires_authentication(api_client, issue, dev, make_comment):
    comment = make_comment(issue, dev)
    url = f"/api/comments/{comment.id}/"

    anonymous = api_client.patch(url, {"body": "Edited."}, format="json")
    assert anonymous.status_code == 401
    assert anonymous.json() == {"error": "authentication required"}

    unknown = api_client.patch(url, {"body": "Edited."}, format="json", HTTP_X_USER_ID="99999")
    assert unknown.status_code == 401
    assert unknown.json() == {"error": "authentication required"}


def test_deleted_comment_hidden_from_list_and_count(api_client, issue, dev, make_comment):
    keep = make_comment(issue, dev, body="Keep me.", age_minutes=10)
    remove = make_comment(issue, dev, body="Wrong issue, sorry.", age_minutes=5)

    deleted = api_client.delete(f"/api/comments/{remove.id}/", **as_member(dev))
    assert deleted.status_code == 204

    listing = api_client.get(comments_url(issue), **as_member(dev))
    assert [c["id"] for c in listing.json()] == [keep.id]
    detail = api_client.get(f"/api/issues/{issue.id}/", **as_member(dev))
    assert detail.json()["comment_count"] == 1
    assert Comment.objects.filter(pk=remove.pk).exists()
