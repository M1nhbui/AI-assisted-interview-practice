# Returns Risk Service

## Issue

Our online electronics store scores every return request for fraud risk and decides whether to approve it, send it to manual review, or mark the item non-returnable. Since the last release, the returns team has reported:

- Ordinary low-risk returns from long-time customers are getting high risk scores and are no longer auto-approved.
- Customers with no recent returns are still getting return-history points.
- The return summary endpoint for customers was never finished and fails every time.

Fix the service so it follows the scoring rules and the API contract below.

## About the service

A small JSON API. A customer submits a return for an item they bought; the service computes a risk score from four factors, picks a decision, and stores the request. There is no frontend and no login flow: the caller identifies themselves with the `X-User-Id` header (a customer id).

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
```

## Running the tests

```bash
./t                                         # whole suite
./t tests/test_scoring.py::test_item_value_tiers
./t -k threshold                            # by name
```

`./t` runs pytest with any arguments you pass and appends a one-line summary to `../test_runs.log`.

## Scoring rules

The risk score is the sum of four components, capped at 100. All boundaries are exact: read "from X" as "X or more" and "below X" as "less than X".

1. **Item value** (`item_value`), from the item's price:
   - below $50: 0
   - from $50 and below $200: 15
   - from $200 and below $1000: 30
   - from $1000: 45
2. **Item rating** (`item_rating`), from the 1 to 5 rating the customer gives the item in the return request. Returning an item you rate highly is unusual, so high ratings add risk:
   - 4 or 5: 20
   - 3: 10
   - 1 or 2: 0
3. **Account age** (`account_age`), in whole days since the customer's account was created, at the time of the request:
   - below 30 days: 25
   - from 30 days and below 180 days: 10
   - from 180 days: 0
4. **Return history** (`return_history`): 5 points for each of the customer's earlier return requests created in the last 90 days (created at or after "now minus 90 days"), up to a maximum of 20. Returns older than 90 days do not count. The request being scored does not count itself.

`reasons` lists the names of the components that scored more than 0, in the order above (`item_value`, `item_rating`, `account_age`, `return_history`).

**Decision**, from the final score:
- below 40: `approved`
- from 40 and below 70: `manual_review`
- from 70: `non_returnable`

**Return window**: a return is accepted up to and including 30 days after the purchase date. Later than that: `400 return window closed`.

## API contract

All endpoints live under `/api/`, accept and return JSON, and require `X-User-Id`. Errors always have the body `{"error": "<message>"}` with the exact message listed. Checks run in the order listed; the first failing one decides the response. Every endpoint starts with `401 authentication required` when the header is missing, not a number, or not a customer.

### POST /api/returns/

- Required fields: `item_id` (int), `purchased_on` (`YYYY-MM-DD`), `item_rating` (int 1 to 5)
- Success: `201` with `{"id", "customer", "item", "purchased_on", "item_rating", "risk_score", "decision", "reasons", "created_at"}`
- Errors, in order:
  - `400` `item_id is required`, `purchased_on is required`, `purchased_on must be a date (YYYY-MM-DD)`, `item_rating is required`, or `item_rating must be between 1 and 5`
  - `404` `item not found`
  - `400` `purchased_on cannot be in the future`
  - `400` `return window closed`

### GET /api/returns/{id}/

- Success: `200` with the return request (same shape as above)
- Errors: `404` `return not found`; `403` `forbidden` when the return belongs to another customer

### GET /api/customers/{id}/returns/summary/

A customer's own return summary across all their return requests.

- Success: `200` with `{"total": <int>, "approved": <int>, "manual_review": <int>, "non_returnable": <int>, "average_risk_score": <number or null>}`
  - The three decision counts are always present, even when 0.
  - `average_risk_score` is the mean `risk_score` rounded to 2 decimal places, or `null` when the customer has no returns.
- Errors: `403` `forbidden` when `{id}` is not the caller
