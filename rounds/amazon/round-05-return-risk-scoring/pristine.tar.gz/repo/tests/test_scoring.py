def test_low_risk_return_is_approved(make_customer, make_item, submit_return):
    customer = make_customer(account_age_days=400)
    item = make_item("25.00", name="USB cable")

    response = submit_return(customer, item, item_rating=1)

    assert response.status_code == 201
    body = response.json()
    assert body["risk_score"] == 0
    assert body["decision"] == "approved"
    assert body["reasons"] == []


def test_item_value_tiers(make_customer, make_item, submit_return):
    customer = make_customer(account_age_days=400)
    expected = {"49.99": 0, "50.00": 15, "199.99": 15, "200.00": 30, "999.99": 30, "1000.00": 45}

    scores = {}
    for price in expected:
        item = make_item(price)
        scores[price] = submit_return(make_customer(account_age_days=400), item, item_rating=1).json()["risk_score"]

    assert scores == expected


def test_new_account_and_positive_rating_add_risk(make_customer, make_item, submit_return):
    customer = make_customer(account_age_days=10)
    item = make_item("25.00", name="Phone case")

    response = submit_return(customer, item, item_rating=5)

    assert response.status_code == 201
    body = response.json()
    assert body["risk_score"] == 45
    assert body["decision"] == "manual_review"
    assert body["reasons"] == ["item_rating", "account_age"]

    middle_aged = make_customer(account_age_days=90)
    neutral = submit_return(middle_aged, make_item("25.00"), item_rating=3).json()
    assert neutral["risk_score"] == 20
    assert neutral["reasons"] == ["item_rating", "account_age"]


def test_recent_return_history_adds_risk(make_customer, make_item, past_return, submit_return):
    customer = make_customer(account_age_days=400)
    old_item = make_item("25.00")
    for days_ago in (5, 20, 60):
        past_return(customer, old_item, days_ago=days_ago)
    past_return(customer, old_item, days_ago=200)

    response = submit_return(customer, make_item("25.00"), item_rating=1)

    assert response.json()["risk_score"] == 15
    assert response.json()["reasons"] == ["return_history"]

    frequent = make_customer(name="Frequent", account_age_days=400)
    for days_ago in range(1, 8):
        past_return(frequent, old_item, days_ago=days_ago)
    capped = submit_return(frequent, make_item("25.00"), item_rating=1).json()
    assert capped["risk_score"] == 20


def test_decision_thresholds(make_customer, make_item, past_return, submit_return):
    customer = make_customer(account_age_days=90)
    past_return(customer, make_item("10.00"), days_ago=10)

    exactly_forty = submit_return(customer, make_item("60.00"), item_rating=3).json()
    assert exactly_forty["risk_score"] == 40
    assert exactly_forty["decision"] == "manual_review"

    newcomer = make_customer(name="Newcomer", account_age_days=2)
    exactly_seventy = submit_return(newcomer, make_item("1000.00"), item_rating=1).json()
    assert exactly_seventy["risk_score"] == 70
    assert exactly_seventy["decision"] == "non_returnable"


def test_return_window_and_validation(api_client, make_customer, make_item, submit_return):
    customer = make_customer()
    item = make_item("25.00")

    assert submit_return(customer, item, purchased_days_ago=30).status_code == 201
    late = submit_return(customer, item, purchased_days_ago=31)
    assert late.status_code == 400
    assert late.json() == {"error": "return window closed"}

    bad_rating = submit_return(customer, item, item_rating=6)
    assert bad_rating.status_code == 400
    assert bad_rating.json() == {"error": "item_rating must be between 1 and 5"}

    anonymous = api_client.post("/api/returns/", {"item_id": item.id}, format="json")
    assert anonymous.status_code == 401


def test_return_summary(api_client, make_customer, make_item, past_return):
    customer = make_customer()
    item = make_item("25.00")
    past_return(customer, item, days_ago=3, risk_score=10, decision="approved")
    past_return(customer, item, days_ago=2, risk_score=45, decision="manual_review")
    past_return(customer, item, days_ago=1, risk_score=70, decision="non_returnable")
    url = f"/api/customers/{customer.id}/returns/summary/"

    response = api_client.get(url, HTTP_X_USER_ID=str(customer.id))

    assert response.status_code == 200
    assert response.json() == {
        "total": 3,
        "approved": 1,
        "manual_review": 1,
        "non_returnable": 1,
        "average_risk_score": 41.67,
    }

    newcomer = make_customer(name="Empty")
    empty = api_client.get(
        f"/api/customers/{newcomer.id}/returns/summary/", HTTP_X_USER_ID=str(newcomer.id)
    )
    assert empty.json() == {
        "total": 0,
        "approved": 0,
        "manual_review": 0,
        "non_returnable": 0,
        "average_risk_score": None,
    }

    other = api_client.get(url, HTTP_X_USER_ID=str(newcomer.id))
    assert other.status_code == 403
    assert other.json() == {"error": "forbidden"}
