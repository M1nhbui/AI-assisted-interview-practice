from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from returns.models import Customer, Item, ReturnRequest


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def make_customer(db):
    def _make_customer(name="Casey", account_age_days=400):
        return Customer.objects.create(
            name=name,
            account_created_at=timezone.now() - timedelta(days=account_age_days),
        )

    return _make_customer


@pytest.fixture
def make_item(db):
    counter = {"n": 0}

    def _make_item(price, name="Item"):
        counter["n"] += 1
        return Item.objects.create(sku=f"SKU-{counter['n']:04d}", name=name, price=price)

    return _make_item


@pytest.fixture
def past_return(db):
    def _past_return(customer, item, days_ago, risk_score=0, decision="approved"):
        return ReturnRequest.objects.create(
            customer=customer,
            item=item,
            purchased_on=(timezone.now() - timedelta(days=days_ago + 5)).date(),
            item_rating=3,
            risk_score=risk_score,
            decision=decision,
            reasons=[],
            created_at=timezone.now() - timedelta(days=days_ago),
        )

    return _past_return


@pytest.fixture
def submit_return(api_client):
    def _submit(customer, item, item_rating=1, purchased_days_ago=3):
        payload = {
            "item_id": item.id,
            "purchased_on": (timezone.now() - timedelta(days=purchased_days_ago)).date().isoformat(),
            "item_rating": item_rating,
        }
        return api_client.post(
            "/api/returns/", payload, format="json", HTTP_X_USER_ID=str(customer.id)
        )

    return _submit
