Your task is to fix this backend issue. Refer to the README.md file for more details.

Note: The acceptance criteria for this task require that your solution pass all predefined unit tests.
