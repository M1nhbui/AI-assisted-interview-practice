# Architecture

```
config/                 Django project: settings, root URLs
returns/
  models.py             Customer, Item, ReturnRequest
  scoring.py            pure scoring: one function per component, decide(), score_return()
  services.py           create_return (window check, scoring, save), summarize_returns
  serializers.py        request validation and response shape
  views.py              one APIView per URL; runs the checks in the README order
  urls.py               routes under /api/
  auth.py               reads X-User-Id
tests/                  pytest-django tests and fixtures
```

## Models

- `Customer`: `name`, `account_created_at`.
- `Item`: `sku`, `name`, `price` (Decimal, dollars).
- `ReturnRequest`: `customer`, `item`, `purchased_on`, `item_rating`, `risk_score`, `decision`, `reasons` (JSON list), `created_at`.

## Flow of POST /api/returns/

1. `auth.resolve_customer`, then `ReturnCreateSerializer` validates the body.
2. The view loads the item and rejects future purchase dates.
3. `services.create_return` checks the return window, calls `scoring.score_return` (which sums `value_points`, `rating_points`, `account_points`, `history_points` and caps the total), calls `scoring.decide`, and saves the request.

## Summary endpoint

`views.ReturnSummaryView` checks auth and ownership, then returns `services.summarize_returns(customer)` as the response body.
