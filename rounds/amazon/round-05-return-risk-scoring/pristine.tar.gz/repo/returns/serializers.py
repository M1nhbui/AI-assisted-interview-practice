from rest_framework import serializers

from .models import ReturnRequest

RATING_ERRORS = {
    "required": "item_rating is required",
    "null": "item_rating is required",
    "invalid": "item_rating must be between 1 and 5",
    "min_value": "item_rating must be between 1 and 5",
    "max_value": "item_rating must be between 1 and 5",
}


class ReturnCreateSerializer(serializers.Serializer):
    item_id = serializers.IntegerField(error_messages={"required": "item_id is required", "invalid": "item_id is required"})
    purchased_on = serializers.DateField(
        error_messages={"required": "purchased_on is required", "invalid": "purchased_on must be a date (YYYY-MM-DD)"}
    )
    item_rating = serializers.IntegerField(min_value=1, max_value=5, error_messages=RATING_ERRORS)


class ReturnSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReturnRequest
        fields = [
            "id", "customer", "item", "purchased_on", "item_rating",
            "risk_score", "decision", "reasons", "created_at",
        ]
