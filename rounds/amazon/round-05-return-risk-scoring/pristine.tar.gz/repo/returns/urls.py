from django.urls import path

from .views import ReturnDetailView, ReturnListCreateView, ReturnSummaryView

urlpatterns = [
    path("returns/", ReturnListCreateView.as_view(), name="return-create"),
    path("returns/<int:return_id>/", ReturnDetailView.as_view(), name="return-detail"),
    path(
        "customers/<int:customer_id>/returns/summary/",
        ReturnSummaryView.as_view(),
        name="return-summary",
    ),
]
