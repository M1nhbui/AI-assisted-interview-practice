from django.db import models
from django.utils import timezone


class Customer(models.Model):
    name = models.CharField(max_length=100)
    account_created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.name


class Item(models.Model):
    sku = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.sku} {self.name}"


class ReturnRequest(models.Model):
    DECISION_APPROVED = "approved"
    DECISION_MANUAL_REVIEW = "manual_review"
    DECISION_NON_RETURNABLE = "non_returnable"
    DECISION_CHOICES = [
        (DECISION_APPROVED, "Approved"),
        (DECISION_MANUAL_REVIEW, "Manual review"),
        (DECISION_NON_RETURNABLE, "Non-returnable"),
    ]

    customer = models.ForeignKey(
        Customer, related_name="return_requests", on_delete=models.CASCADE
    )
    item = models.ForeignKey(Item, related_name="return_requests", on_delete=models.CASCADE)
    purchased_on = models.DateField()
    item_rating = models.PositiveSmallIntegerField()
    risk_score = models.PositiveIntegerField()
    decision = models.CharField(max_length=20, choices=DECISION_CHOICES)
    reasons = models.JSONField(default=list)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Return {self.pk} ({self.decision})"
