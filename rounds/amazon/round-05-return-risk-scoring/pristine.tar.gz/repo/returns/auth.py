from .models import Customer

USER_HEADER = "X-User-Id"


def resolve_customer(request):
    raw = request.headers.get(USER_HEADER, "").strip()
    if not raw.isdigit():
        return None
    return Customer.objects.filter(pk=int(raw)).first()
