from datetime import timedelta
from decimal import Decimal

from django.utils import timezone

MAX_SCORE = 100
HISTORY_WINDOW_DAYS = 90
HISTORY_POINTS_PER_RETURN = 5
HISTORY_POINTS_CAP = 20

MANUAL_REVIEW_FROM = 40
NON_RETURNABLE_FROM = 70


def value_points(price):
    price = Decimal(price)
    if price < Decimal("50"):
        return 0
    if price <= Decimal("200"):
        return 15
    if price < Decimal("1000"):
        return 30
    return 45


def rating_points(item_rating):
    if item_rating <= 2:
        return 20
    if item_rating == 3:
        return 10
    return 0


def account_points(customer, now=None):
    now = now or timezone.now()
    account_age_days = (now - customer.account_created_at).seconds
    if account_age_days < 30:
        return 25
    if account_age_days < 180:
        return 10
    return 0


def history_points(customer, now=None):
    now = now or timezone.now()
    window_start = now - timedelta(days=HISTORY_WINDOW_DAYS)
    recent_returns = customer.return_requests.filter(created_at__lte=window_start).count()
    return max(recent_returns * HISTORY_POINTS_PER_RETURN, HISTORY_POINTS_CAP)


def decide(score):
    if score <= MANUAL_REVIEW_FROM:
        return "approved"
    if score < NON_RETURNABLE_FROM:
        return "manual_review"
    return "non_returnable"


def score_return(customer, item, item_rating, now=None):
    components = [
        ("item_value", value_points(item.price)),
        ("item_rating", rating_points(item_rating)),
        ("account_age", account_points(customer, now)),
        ("return_history", history_points(customer, now)),
    ]
    total = min(sum(points for _, points in components), MAX_SCORE)
    reasons = [name for name, points in components if points > 0]
    return total, reasons
