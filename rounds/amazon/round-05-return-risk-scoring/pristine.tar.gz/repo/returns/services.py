from django.utils import timezone

from .models import ReturnRequest
from .scoring import decide, score_return

RETURN_WINDOW_DAYS = 30


class ReturnWindowClosed(Exception):
    pass


def create_return(customer, item, purchased_on, item_rating):
    now = timezone.now()
    days_since_purchase = (now.date() - purchased_on).days
    if days_since_purchase > RETURN_WINDOW_DAYS:
        raise ReturnWindowClosed()

    risk_score, reasons = score_return(customer, item, item_rating, now)
    return ReturnRequest.objects.create(
        customer=customer,
        item=item,
        purchased_on=purchased_on,
        item_rating=item_rating,
        risk_score=risk_score,
        decision=decide(risk_score),
        reasons=reasons,
        created_at=now,
    )


def summarize_returns(customer):
    raise NotImplementedError
