from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .auth import resolve_customer
from .models import Item, ReturnRequest
from .serializers import ReturnCreateSerializer, ReturnSerializer
from .services import ReturnWindowClosed, create_return, summarize_returns


def error(message, code):
    return Response({"error": message}, status=code)


def first_error(errors):
    messages = next(iter(errors.values()))
    return str(messages[0])


def unauthenticated():
    return error("authentication required", status.HTTP_401_UNAUTHORIZED)


class ReturnListCreateView(APIView):
    def post(self, request):
        customer = resolve_customer(request)
        if customer is None:
            return unauthenticated()

        serializer = ReturnCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)
        data = serializer.validated_data

        item = Item.objects.filter(pk=data["item_id"]).first()
        if item is None:
            return error("item not found", status.HTTP_404_NOT_FOUND)
        if data["purchased_on"] > timezone.now().date():
            return error("purchased_on cannot be in the future", status.HTTP_400_BAD_REQUEST)

        try:
            return_request = create_return(
                customer=customer,
                item=item,
                purchased_on=data["purchased_on"],
                item_rating=data["item_rating"],
            )
        except ReturnWindowClosed:
            return error("return window closed", status.HTTP_400_BAD_REQUEST)

        return Response(ReturnSerializer(return_request).data, status=status.HTTP_201_CREATED)


class ReturnDetailView(APIView):
    def get(self, request, return_id):
        customer = resolve_customer(request)
        if customer is None:
            return unauthenticated()

        return_request = ReturnRequest.objects.filter(pk=return_id).first()
        if return_request is None:
            return error("return not found", status.HTTP_404_NOT_FOUND)
        if return_request.customer_id != customer.id:
            return error("forbidden", status.HTTP_403_FORBIDDEN)
        return Response(ReturnSerializer(return_request).data)


class ReturnSummaryView(APIView):
    def get(self, request, customer_id):
        customer = resolve_customer(request)
        if customer is None:
            return unauthenticated()
        if customer.id != customer_id:
            return error("forbidden", status.HTTP_403_FORBIDDEN)
        return Response(summarize_returns(customer))
