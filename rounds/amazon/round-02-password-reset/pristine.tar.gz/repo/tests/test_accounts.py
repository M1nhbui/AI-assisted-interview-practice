from accounts.models import Account


def test_register_account(api_client, db):
    payload = {"email": "cara@example.com", "password": "carapass123"}

    response = api_client.post("/api/accounts/", payload, format="json")

    assert response.status_code == 201
    body = response.json()
    assert body["email"] == "cara@example.com"
    assert "password" not in body
    saved = Account.objects.get(email="cara@example.com")
    assert saved.id == body["id"]
    assert saved.password != "carapass123"
    assert saved.check_password("carapass123")

    duplicate = api_client.post("/api/accounts/", payload, format="json")

    assert duplicate.status_code == 409
    assert duplicate.json() == {"error": "email already registered"}
    assert Account.objects.filter(email="cara@example.com").count() == 1


def test_account_detail_requires_matching_user(api_client, account, other_account):
    url = f"/api/accounts/{account.id}/"

    anonymous = api_client.get(url)
    assert anonymous.status_code == 401
    assert anonymous.json() == {"error": "authentication required"}

    stranger = api_client.get(url, HTTP_X_USER_ID=str(other_account.id))
    assert stranger.status_code == 403
    assert stranger.json() == {"error": "forbidden"}

    owner = api_client.get(url, HTTP_X_USER_ID=str(account.id))
    assert owner.status_code == 200
    assert owner.json() == {
        "id": account.id,
        "email": "ana@example.com",
        "password_changed_at": None,
    }
