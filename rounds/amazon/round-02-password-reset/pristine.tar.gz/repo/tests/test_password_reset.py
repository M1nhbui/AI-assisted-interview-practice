from accounts.models import ResetCode

REQUEST_URL = "/api/password-reset/request/"
VERIFY_URL = "/api/password-reset/verify/"
CONFIRM_URL = "/api/password-reset/confirm/"
LOGIN_URL = "/api/login/"


def test_request_reset_creates_code(api_client, account):
    response = api_client.post(REQUEST_URL, {"email": account.email}, format="json")

    assert response.status_code == 201
    assert response.json() == {"message": "Verification code sent"}
    codes = ResetCode.objects.filter(account=account)
    assert codes.count() == 1
    reset_code = codes.get()
    assert len(reset_code.code) == 6
    assert reset_code.code.isdigit()
    assert reset_code.verified is False
    assert reset_code.used is False


def test_verify_code(api_client, account, make_code):
    reset_code = make_code(account, code="482913")

    wrong = api_client.post(
        VERIFY_URL, {"email": account.email, "code": "000000"}, format="json"
    )
    assert wrong.status_code == 400
    assert wrong.json() == {"error": "invalid code"}

    response = api_client.post(
        VERIFY_URL, {"email": account.email, "code": "482913"}, format="json"
    )
    assert response.status_code == 200
    assert response.json() == {"message": "Code verified"}
    reset_code.refresh_from_db()
    assert reset_code.verified is True


def test_verify_rejects_expired_code(api_client, account, make_code):
    reset_code = make_code(account, code="271828", age_seconds=45)

    response = api_client.post(
        VERIFY_URL, {"email": account.email, "code": "271828"}, format="json"
    )

    assert response.status_code == 410
    assert response.json() == {"error": "code expired"}
    reset_code.refresh_from_db()
    assert reset_code.verified is False


def test_confirm_reset_persists_new_password(api_client, account, make_code):
    make_code(account, code="314159", verified=True)

    response = api_client.post(
        CONFIRM_URL,
        {"email": account.email, "code": "314159", "new_password": "brandnew123"},
        format="json",
    )

    assert response.status_code == 200
    assert response.json() == {"message": "Password updated"}
    account.refresh_from_db()
    assert account.check_password("brandnew123")
    assert account.password_changed_at is not None

    new_login = api_client.post(
        LOGIN_URL, {"email": account.email, "password": "brandnew123"}, format="json"
    )
    assert new_login.status_code == 200
    assert new_login.json() == {"id": account.id, "email": account.email}

    old_login = api_client.post(
        LOGIN_URL, {"email": account.email, "password": "oldpass123"}, format="json"
    )
    assert old_login.status_code == 401
    assert old_login.json() == {"error": "invalid credentials"}
