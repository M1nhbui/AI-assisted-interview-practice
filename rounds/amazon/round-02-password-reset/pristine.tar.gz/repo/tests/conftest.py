from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.models import Account, ResetCode


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def account(db):
    return Account.objects.create(
        email="ana@example.com", password=make_password("oldpass123")
    )


@pytest.fixture
def other_account(db):
    other = Account(email="ben@example.com")
    other.set_password("benpass123")
    other.save()
    return other


@pytest.fixture
def make_code(db):
    def _make_code(account, code="123456", age_seconds=0, verified=False, used=False):
        return ResetCode.objects.create(
            account=account,
            code=code,
            generated_at=timezone.now() - timedelta(seconds=age_seconds),
            verified=verified,
            used=used,
        )

    return _make_code
