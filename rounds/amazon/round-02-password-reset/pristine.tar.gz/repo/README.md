# Account Recovery Service

A small JSON API for user accounts and self-service password resets. Users register with an email and password, sign in, read their own profile, and reset a forgotten password with a short-lived 6-digit verification code.

There is no frontend and no email delivery. In this service the verification code is stored in the database; a separate notification worker (not part of this repo) reads it and sends it to the user.

## Requirements

- Python 3.11 or newer
- The packages in `requirements.txt` (Django 5.2, Django REST Framework, pytest, pytest-django)

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
```

## Running the server

```bash
python manage.py runserver
curl -H "Content-Type: application/json" \
     -d '{"email": "ana@example.com", "password": "secret123"}' \
     http://127.0.0.1:8000/api/accounts/
```

## Running the tests

```bash
./t                                         # whole suite
./t tests/test_password_reset.py            # one file
./t tests/test_accounts.py::test_register_account
./t -k verify                               # by name
```

`./t` runs pytest with any arguments you pass and appends a one-line summary to `../test_runs.log`.

## API contract

All endpoints live under `/api/`, accept and return JSON, and need no session or token. Errors always have the body `{"error": "<message>"}` with the exact message listed below. When a request has several problems, the checks run in the order they are listed for that endpoint, and the first failing check decides the response.

Passwords must be at least 8 characters long. Passwords are stored hashed and are never returned.

### POST /api/accounts/

Register a new account.

- Required fields: `email`, `password`
- Required headers: none
- Success: `201` with `{"id": <int>, "email": "<email>"}`
- Errors:
  - `400` `email is required` when `email` is missing or blank
  - `400` `password is required` when `password` is missing or blank
  - `400` `password must be at least 8 characters`
  - `409` `email already registered`

### GET /api/accounts/{id}/

Read an account profile. A user may only read their own profile.

- Required fields: none
- Required headers: `X-User-Id: <account id of the caller>`
- Success: `200` with `{"id": <int>, "email": "<email>", "password_changed_at": <ISO 8601 timestamp or null>}`
- Errors:
  - `401` `authentication required` when the header is missing, is not a number, or does not match an existing account
  - `403` `forbidden` when the caller is not the owner of account `{id}`

### POST /api/login/

Check a user's credentials.

- Required fields: `email`, `password`
- Required headers: none
- Success: `200` with `{"id": <int>, "email": "<email>"}`
- Errors:
  - `400` `email and password are required`
  - `401` `invalid credentials` when the email is unknown or the password is wrong

### POST /api/password-reset/request/

Start a password reset. Creates a new random 6-digit verification code for the account, stored with the time it was generated. Any earlier codes for the account that have not been used stop working (they are marked used).

- Required fields: `email`
- Required headers: none
- Success: `201` with `{"message": "Verification code sent"}`
- Errors:
  - `400` `email is required`
  - `404` `account not found`

### POST /api/password-reset/verify/

Check a verification code. A code is valid for 30 seconds after it was generated (`PASSWORD_RESET_CODE_TTL_SECONDS` in settings). A code that is verified in time is marked verified.

- Required fields: `email`, `code`
- Required headers: none
- Success: `200` with `{"message": "Code verified"}`
- Errors:
  - `400` `email and code are required`
  - `404` `account not found`
  - `400` `invalid code` when there is no unused code with that value for the account
  - `410` `code expired` when more than 30 seconds have passed since the code was generated (the code is not marked verified)

### POST /api/password-reset/confirm/

Set a new password using a verified code. On success the new password is saved to the account, `password_changed_at` is set to the current time, and the code is marked used so it cannot be used again. After this the user signs in with the new password only.

- Required fields: `email`, `code`, `new_password`
- Required headers: none
- Success: `200` with `{"message": "Password updated"}`
- Errors:
  - `400` `email, code and new_password are required`
  - `400` `password must be at least 8 characters`
  - `404` `account not found`
  - `400` `invalid code` when there is no unused code with that value for the account
  - `400` `code not verified` when the code exists but has not been verified
