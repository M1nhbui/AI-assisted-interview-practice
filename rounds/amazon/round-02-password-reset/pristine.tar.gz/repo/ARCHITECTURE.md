# Architecture

One Django project (`config`) with one app (`accounts`). Plain Django REST Framework `APIView` classes, no DRF authentication classes. The caller's identity for profile reads comes from the `X-User-Id` header.

```
config/
  settings.py      Django settings; PASSWORD_RESET_CODE_TTL_SECONDS = 30
  urls.py          mounts accounts.urls under /api/
accounts/
  models.py        Account, ResetCode
  validators.py    shared password rules
  serializers.py   request validation and response shapes
  services.py      password reset logic (issue, look up, verify, apply)
  auth.py          resolves the X-User-Id header and decides who may read a profile
  views.py         one APIView per endpoint; turns results into HTTP responses
  urls.py          routes
tests/
  conftest.py      shared fixtures
  test_accounts.py
  test_password_reset.py
```

## Models

`Account`: `email` (unique), `password` (a Django password hash, set with `set_password` and checked with `check_password`), `created_at`, `password_changed_at` (null until the first reset).

`ResetCode`: belongs to an `Account` (`account.reset_codes`). Fields: `code` (6 digits as a string), `generated_at`, `verified`, `used`. Newest first. `expires_at` is `generated_at` plus `PASSWORD_RESET_CODE_TTL_SECONDS` seconds, and `is_expired()` is true once the current time is past `expires_at`.

## Request flow

1. The view validates the body with a serializer. Missing or blank fields and too-short passwords give `400` with the message from the README contract. `validators.validate_password_length` is the single place the 8-character minimum is enforced, for both registration and reset.
2. The view looks up the account by email (`404 account not found` if none).
3. The view calls into `services.py` for the reset steps:
   - `issue_reset_code(account)` marks the account's unused codes used, then creates and stores a new code with `generated_at` set to now, and returns it.
   - `find_active_code(account, code)` returns the newest unused code with that value, or `None`.
   - `mark_verified(reset_code)` stores `verified = True`.
   - `apply_new_password(reset_code, new_password)` hashes and stores the new password on the account, stores `password_changed_at`, and stores `used = True` on the code.
4. The view returns the status and body from the README contract.

## Profile access

`auth.resolve_requester(request)` returns the `Account` named by `X-User-Id`, or `None` if the header is missing, not a number, or unknown (the view answers `401`). `auth.can_view_account(requester, account_id)` is true only when the requester owns that account; otherwise the view answers `403`.

## Tests

Tests use pytest-django and DRF's `APIClient`. They check the status code, the exact JSON body, and what is stored in the database.
