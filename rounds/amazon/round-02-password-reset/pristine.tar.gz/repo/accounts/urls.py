from django.urls import path

from . import views

urlpatterns = [
    path("accounts/", views.RegisterView.as_view(), name="account-register"),
    path("accounts/<int:pk>/", views.AccountDetailView.as_view(), name="account-detail"),
    path("login/", views.LoginView.as_view(), name="login"),
    path("password-reset/request/", views.RequestResetView.as_view(), name="reset-request"),
    path("password-reset/verify/", views.VerifyCodeView.as_view(), name="reset-verify"),
    path("password-reset/confirm/", views.ConfirmResetView.as_view(), name="reset-confirm"),
]
