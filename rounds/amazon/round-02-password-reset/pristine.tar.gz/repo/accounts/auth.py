from .models import Account

USER_HEADER = "X-User-Id"


def resolve_requester(request):
    raw = request.headers.get(USER_HEADER, "").strip()
    if not raw.isdigit():
        return None
    return Account.objects.filter(pk=int(raw)).first()


def can_view_account(requester, account_id):
    return requester.id != account_id
