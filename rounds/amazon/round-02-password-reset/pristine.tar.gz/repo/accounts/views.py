from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .auth import can_view_account, resolve_requester
from .models import Account
from .serializers import (
    AccountSerializer,
    ConfirmResetSerializer,
    LoginSerializer,
    RegisterSerializer,
    ResetRequestSerializer,
    VerifyCodeSerializer,
)
from .services import (
    apply_new_password,
    find_active_code,
    issue_reset_code,
    mark_verified,
)


def error(message, code):
    return Response({"error": message}, status=code)


def first_error(errors):
    messages = next(iter(errors.values()))
    return str(messages[0])


def find_account(email):
    return Account.objects.filter(email=email).first()


class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        email = serializer.validated_data["email"]
        if Account.objects.filter(email=email).exists():
            return error("email already registered", status.HTTP_409_CONFLICT)

        account = Account(email=email)
        account.set_password(serializer.validated_data["password"])
        account.save()
        return Response(
            {"id": account.id, "email": account.email},
            status=status.HTTP_201_CREATED,
        )


class AccountDetailView(APIView):
    def get(self, request, pk):
        requester = resolve_requester(request)
        if requester is None:
            return error("authentication required", status.HTTP_401_UNAUTHORIZED)
        if not can_view_account(requester, pk):
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        account = Account.objects.filter(pk=pk).first()
        if account is None:
            return error("account not found", status.HTTP_404_NOT_FOUND)
        return Response(AccountSerializer(account).data)


class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        account = find_account(serializer.validated_data["email"])
        if account is None or not account.check_password(
            serializer.validated_data["password"]
        ):
            return error("invalid credentials", status.HTTP_401_UNAUTHORIZED)
        return Response({"id": account.id, "email": account.email})


class RequestResetView(APIView):
    def post(self, request):
        serializer = ResetRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        account = find_account(serializer.validated_data["email"])
        if account is None:
            return error("account not found", status.HTTP_404_NOT_FOUND)

        issue_reset_code(account)
        return Response(
            {"message": "Verification code sent"}, status=status.HTTP_201_CREATED
        )


class VerifyCodeView(APIView):
    def post(self, request):
        serializer = VerifyCodeSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        account = find_account(serializer.validated_data["email"])
        if account is None:
            return error("account not found", status.HTTP_404_NOT_FOUND)

        reset_code = find_active_code(account, serializer.validated_data["code"])
        if reset_code is None:
            return error("invalid code", status.HTTP_400_BAD_REQUEST)
        if reset_code.is_expired():
            return error("code expired", status.HTTP_410_GONE)

        mark_verified(reset_code)
        return Response({"message": "Code verified"})


class ConfirmResetView(APIView):
    def post(self, request):
        serializer = ConfirmResetSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        account = find_account(serializer.validated_data["email"])
        if account is None:
            return error("account not found", status.HTTP_404_NOT_FOUND)

        reset_code = find_active_code(account, serializer.validated_data["code"])
        if reset_code is None:
            return error("invalid code", status.HTTP_400_BAD_REQUEST)
        if not reset_code.verified:
            return error("code not verified", status.HTTP_400_BAD_REQUEST)

        apply_new_password(reset_code, serializer.validated_data["new_password"])
        return Response({"message": "Password updated"})
