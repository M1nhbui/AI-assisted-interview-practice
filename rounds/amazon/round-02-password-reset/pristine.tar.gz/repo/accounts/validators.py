from rest_framework import serializers

MIN_PASSWORD_LENGTH = 8


def validate_password_length(value):
    if len(value) <= MIN_PASSWORD_LENGTH:
        raise serializers.ValidationError(
            f"password must be at least {MIN_PASSWORD_LENGTH} characters"
        )
    return value
