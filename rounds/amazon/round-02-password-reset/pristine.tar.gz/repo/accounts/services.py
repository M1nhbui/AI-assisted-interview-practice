import random

from django.utils import timezone

from .models import ResetCode


def generate_code():
    return f"{random.randint(0, 999999):06d}"


def issue_reset_code(account):
    account.reset_codes.filter(used=False).update(used=True)
    reset_code = ResetCode(
        account=account,
        code=generate_code(),
        generated_at=timezone.now(),
    )
    return reset_code


def find_active_code(account, code):
    return account.reset_codes.filter(code=code, used=False).first()


def mark_verified(reset_code):
    reset_code.verified = True
    reset_code.save(update_fields=["verified"])
    return reset_code


def apply_new_password(reset_code, new_password):
    account = reset_code.account
    account.set_password(new_password)
    account.password_changed_at = timezone.now()
    account.save(update_fields=["password_changed_at"])
    reset_code.used = True
    reset_code.save(update_fields=["used"])
    return account
