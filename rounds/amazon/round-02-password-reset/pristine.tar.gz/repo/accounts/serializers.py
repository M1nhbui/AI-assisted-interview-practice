from rest_framework import serializers

from .models import Account
from .validators import validate_password_length


def required_field(message, **kwargs):
    return serializers.CharField(
        error_messages={"required": message, "blank": message, "null": message},
        **kwargs,
    )


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ["id", "email", "password_changed_at"]


class RegisterSerializer(serializers.Serializer):
    email = required_field("email is required")
    password = required_field("password is required", trim_whitespace=False)

    def validate_password(self, value):
        return validate_password_length(value)


class LoginSerializer(serializers.Serializer):
    email = required_field("email and password are required")
    password = required_field("email and password are required", trim_whitespace=False)


class ResetRequestSerializer(serializers.Serializer):
    email = required_field("email is required")


class VerifyCodeSerializer(serializers.Serializer):
    email = required_field("email and code are required")
    code = required_field("email and code are required")


class ConfirmResetSerializer(serializers.Serializer):
    email = required_field("email, code and new_password are required")
    code = required_field("email, code and new_password are required")
    new_password = required_field(
        "email, code and new_password are required", trim_whitespace=False
    )

    def validate_new_password(self, value):
        return validate_password_length(value)
