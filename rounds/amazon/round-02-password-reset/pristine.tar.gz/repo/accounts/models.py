from datetime import timedelta

from django.conf import settings
from django.contrib.auth.hashers import check_password, make_password
from django.db import models
from django.utils import timezone


class Account(models.Model):
    email = models.CharField(max_length=254, unique=True)
    password = models.CharField(max_length=128)
    created_at = models.DateTimeField(auto_now_add=True)
    password_changed_at = models.DateTimeField(null=True, blank=True)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.email


class ResetCode(models.Model):
    account = models.ForeignKey(
        Account, related_name="reset_codes", on_delete=models.CASCADE
    )
    code = models.CharField(max_length=6)
    generated_at = models.DateTimeField(default=timezone.now)
    verified = models.BooleanField(default=False)
    used = models.BooleanField(default=False)

    class Meta:
        ordering = ["-generated_at", "-id"]

    @property
    def expires_at(self):
        ttl = settings.PASSWORD_RESET_CODE_TTL_SECONDS
        return self.generated_at + timedelta(minutes=ttl)

    def is_expired(self, now=None):
        now = now or timezone.now()
        return now > self.expires_at

    def __str__(self):
        return f"{self.account.email} {self.code}"
