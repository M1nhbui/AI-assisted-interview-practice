# Task: Account Recovery Service

This repository contains a small JSON API that lets users create an account, sign in, view their own profile, and recover access when they forget their password. A user who forgets their password asks for a reset, receives a 6-digit verification code, confirms the code within 30 seconds, and then chooses a new password.

Support has received several complaints since the last release.

## Reported issues

- Users who ask for a password reset never get a verification code they can use.
- Verification codes keep working long after the 30-second window has closed.
- After completing a password reset, users can still only sign in with their old password.

Pass as many tests as possible. Behavior must follow the API contract in README.md.
