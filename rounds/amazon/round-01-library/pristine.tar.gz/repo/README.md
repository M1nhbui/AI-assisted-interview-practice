# Branch Library API

A small JSON API for a neighborhood library branch. Staff keep the catalog of books, the front desk registers members, and members borrow and return copies. The API tracks how many copies of each book are on the shelf, enforces each member's loan limit, and charges a late fee when a book comes back after its due date.

There is no frontend. Every endpoint lives under `/api/` and speaks JSON.

## Requirements

- Python 3.11 or newer
- The packages in `requirements.txt` (Django 5.2, Django REST Framework, pytest, pytest-django)

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser   # a staff account for catalog changes
```

## Running the server

```bash
python manage.py runserver
```

The API uses HTTP Basic or session authentication. Every endpoint requires a logged-in user. Example:

```bash
curl -u admin:password http://127.0.0.1:8000/api/books/
curl -u admin:password -H "Content-Type: application/json" \
     -d '{"book": 1, "member": 1}' http://127.0.0.1:8000/api/loans/
```

## Running the tests

```bash
./t                                   # whole suite
./t tests/test_loans.py               # one file
./t tests/test_loans.py::test_return_loan
./t -k borrow                         # tests whose name matches "borrow"
```

`./t` is a thin wrapper around `python -m pytest` and passes its arguments straight through. It also appends a one-line summary of each run to `../test_runs.log`.

## Project layout

```
config/            Django project settings and root URL config
library/
  models.py        Book, Member, Loan
  serializers.py   request/response shapes and input validation
  permissions.py   catalog write access
  services.py      lending rules (availability, limits, due dates, late fees)
  views.py         DRF viewsets
  urls.py          router registration
tests/             pytest suite
```

See `ARCHITECTURE.md` for how the pieces fit together and the exact behavior of each endpoint.
