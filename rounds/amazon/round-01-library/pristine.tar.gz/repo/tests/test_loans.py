from datetime import timedelta

from django.utils import timezone

from library.models import Loan


def test_borrow_book(client, make_book, make_member):
    book = make_book(total_copies=2)
    member = make_member()

    response = client.post("/api/loans/", {"book": book.id, "member": member.id}, format="json")

    assert response.status_code == 201
    body = response.json()
    assert body["status"] == "active"
    assert body["due_date"] == (timezone.localdate() + timedelta(days=14)).isoformat()
    assert Loan.objects.filter(book=book, member=member, returned_on__isnull=True).count() == 1


def test_cannot_borrow_when_all_copies_are_out(client, make_book, make_member, make_loan):
    book = make_book(total_copies=1)
    make_loan(book, make_member())

    response = client.post(
        "/api/loans/", {"book": book.id, "member": make_member().id}, format="json"
    )

    assert response.status_code == 400
    assert Loan.objects.filter(book=book).count() == 1


def test_return_loan(client, make_book, make_member, make_loan):
    loan = make_loan(make_book(), make_member(), borrowed_days_ago=3)

    response = client.post(f"/api/loans/{loan.id}/return/")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "returned"
    assert body["late_fee"] == "0.00"
    loan.refresh_from_db()
    assert loan.returned_on == timezone.localdate()


def test_list_loans_for_member(client, make_book, make_member, make_loan):
    alice = make_member(name="Alice")
    bob = make_member(name="Bob")
    make_loan(make_book(), alice)
    make_loan(make_book(), bob)
    make_loan(make_book(), alice, borrowed_days_ago=5)

    response = client.get(f"/api/loans/?member={alice.id}")

    assert response.status_code == 200
    loans = response.json()
    assert len(loans) == 2
    assert {loan["member"] for loan in loans} == {alice.id}
