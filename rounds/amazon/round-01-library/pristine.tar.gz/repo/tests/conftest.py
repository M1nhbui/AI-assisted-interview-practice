from datetime import timedelta

import pytest
from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework.test import APIClient

from library.models import Book, Loan, Member


@pytest.fixture
def staff_user(db):
    return get_user_model().objects.create_user(
        username="librarian", password="pass1234", is_staff=True
    )


@pytest.fixture
def regular_user(db):
    return get_user_model().objects.create_user(username="desk", password="pass1234")


@pytest.fixture
def staff_client(staff_user):
    client = APIClient()
    client.force_authenticate(user=staff_user)
    return client


@pytest.fixture
def client(regular_user):
    client = APIClient()
    client.force_authenticate(user=regular_user)
    return client


@pytest.fixture
def make_book(db):
    counter = {"n": 0}

    def _make_book(**overrides):
        counter["n"] += 1
        data = {
            "title": f"Book {counter['n']}",
            "author": "Some Author",
            "isbn": f"978000000{counter['n']:04d}",
            "total_copies": 1,
        }
        data.update(overrides)
        return Book.objects.create(**data)

    return _make_book


@pytest.fixture
def make_member(db):
    counter = {"n": 0}

    def _make_member(**overrides):
        counter["n"] += 1
        data = {
            "name": f"Member {counter['n']}",
            "email": f"member{counter['n']}@example.com",
        }
        data.update(overrides)
        return Member.objects.create(**data)

    return _make_member


@pytest.fixture
def make_loan(db):
    def _make_loan(book, member, borrowed_days_ago=0, returned=False):
        today = timezone.localdate()
        borrowed_on = today - timedelta(days=borrowed_days_ago)
        return Loan.objects.create(
            book=book,
            member=member,
            borrowed_on=borrowed_on,
            due_date=borrowed_on + timedelta(days=14),
            returned_on=today if returned else None,
        )

    return _make_loan
