from library.models import Book


def test_list_books_sorted_by_title(client, make_book):
    make_book(title="Zen and the Art of Motorcycle Maintenance")
    make_book(title="Anna Karenina")
    make_book(title="Moby Dick")

    response = client.get("/api/books/")

    assert response.status_code == 200
    titles = [book["title"] for book in response.json()]
    assert titles == ["Anna Karenina", "Moby Dick", "Zen and the Art of Motorcycle Maintenance"]


def test_staff_can_add_book(staff_client):
    payload = {
        "title": "The Pragmatic Programmer",
        "author": "Andrew Hunt",
        "isbn": "9780135957059",
        "published_year": 2019,
        "total_copies": 2,
    }

    response = staff_client.post("/api/books/", payload, format="json")

    assert response.status_code == 201
    body = response.json()
    assert body["available_copies"] == 2
    assert Book.objects.filter(isbn="9780135957059").exists()
