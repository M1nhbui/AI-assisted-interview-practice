# Architecture

## Overview

The project is a single Django app, `library`, exposed through Django REST Framework.

```
request -> config/urls.py -> library/urls.py (DefaultRouter)
        -> library/views.py (viewsets)
             -> library/serializers.py   (validate input, shape output)
             -> library/services.py      (lending rules, writes to the DB)
             -> library/models.py
```

Views stay thin. Anything that is a business rule (can this member borrow this book, when is it due, what does a late return cost) lives in `services.py`, so the same rules apply no matter which view calls them. Views translate `services.LoanError` into a `400 Bad Request` with a `{"detail": "..."}` body.

## Data model

| Model | Fields | Notes |
|---|---|---|
| `Book` | `title`, `author`, `isbn` (13 digits, unique), `published_year`, `total_copies`, `created_at` | `total_copies` is how many physical copies the branch owns. |
| `Member` | `name`, `email` (unique), `is_active`, `max_loans` (default 3), `joined_on` | Inactive members cannot borrow. |
| `Loan` | `book`, `member`, `borrowed_on`, `due_date`, `returned_on` (null while out), `late_fee` | A loan is *open* while `returned_on` is null. |

Derived values (computed, not stored):

- **Available copies** of a book = `total_copies` minus the number of *open* loans for that book. Returned loans do not count.
- **Loan status**:
  - `returned`: `returned_on` is set.
  - `overdue`: still open and `due_date` is before today.
  - `active`: still open and `due_date` is today or later.

All dates are calendar dates in the server time zone (UTC).

## Lending rules (`services.py`)

- **Loan period**: 14 days (`LIBRARY_LOAN_PERIOD_DAYS`). A loan made today is due `today + 14 days`.
- **Borrowing** (`borrow_book`) is refused with a `LoanError` when any of these hold, checked in this order:
  1. the member is inactive;
  2. the member already has `max_loans` open loans (a member with `max_loans = 3` may hold at most 3 books at once; overdue loans count as open);
  3. the book has no available copies.
- **Returning** (`return_loan`) sets `returned_on` to today and stores the late fee. Returning a loan that is already returned is a `LoanError`.
- **Late fee**: `0.25` per full day between `due_date` and `returned_on` (`LIBRARY_LATE_FEE_PER_DAY`). Returning on or before the due date costs `0.00`. Example: due on the 10th, returned on the 13th, fee `0.75`.

## Permissions

The default for every endpoint is "authenticated users only" (`401`/`403` for anonymous requests).

The book catalog uses `IsStaffOrReadOnly`:

- any authenticated user may read books (`GET`, `HEAD`, `OPTIONS`);
- only staff users (`is_staff=True`) may create, update or delete books. Non-staff users get `403`.

Members and loans are handled by the front desk, so any authenticated user may use those endpoints.

## Endpoints

List endpoints return a plain JSON array (no pagination). Decimal values such as `late_fee` are serialized as strings with two decimal places, for example `"0.75"`.

### Books

| Method | Path | Behavior |
|---|---|---|
| `GET` | `/api/books/` | All books, sorted by `title` A to Z (ties by `id`). Optional filters: `?author=<text>` (case-insensitive substring match), `?available=true` (only books with at least one available copy). |
| `POST` | `/api/books/` | Staff only. Creates a book, returns `201` with the book. `isbn` must be exactly 13 digits and unique; `total_copies` must be at least 1. Invalid input returns `400`. |
| `GET` | `/api/books/{id}/` | One book. `404` if it does not exist. |
| `PUT`/`PATCH` | `/api/books/{id}/` | Staff only. Same validation as create. |
| `DELETE` | `/api/books/{id}/` | Staff only. `204` on success. A book that has ever been loaned cannot be deleted: `409` with a `detail` message. |

Book representation:

```json
{"id": 1, "title": "Moby Dick", "author": "Herman Melville", "isbn": "9780142437247",
 "published_year": 1851, "total_copies": 2, "available_copies": 1,
 "created_at": "2026-11-01T10:00:00Z"}
```

### Members

| Method | Path | Behavior |
|---|---|---|
| `GET` | `/api/members/` | All members sorted by `name`. |
| `POST` | `/api/members/` | Registers a member, returns `201`. |
| `GET` | `/api/members/{id}/` | One member. |
| `PUT`/`PATCH` | `/api/members/{id}/` | Updates a member, for example to deactivate them or change `max_loans`. |

Members are never deleted; deactivate them instead.

### Loans

| Method | Path | Behavior |
|---|---|---|
| `GET` | `/api/loans/` | Loans sorted by `due_date`, earliest first (ties by `id`). Optional filters, which can be combined: `?member=<member id>` and `?status=active|overdue|returned`. |
| `POST` | `/api/loans/` | Body `{"book": <id>, "member": <id>}`. Applies the borrowing rules above. Success returns `201` with the new loan. A rule violation returns `400` with `{"detail": "..."}` and creates nothing. Unknown book or member ids return `400`. |
| `GET` | `/api/loans/{id}/` | One loan. |
| `POST` | `/api/loans/{id}/return/` | Returns the book. `200` with the updated loan, including `late_fee` and `status: "returned"`. Returning an already-returned loan returns `400`. |

Loans cannot be edited or deleted through the API.

Loan representation:

```json
{"id": 7, "book": 1, "book_title": "Moby Dick", "member": 3, "member_name": "Alice",
 "borrowed_on": "2026-11-01", "due_date": "2026-11-15", "returned_on": null,
 "late_fee": "0.00", "status": "active"}
```
