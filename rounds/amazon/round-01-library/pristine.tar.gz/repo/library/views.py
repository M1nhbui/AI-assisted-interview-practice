from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from . import services
from .models import Book, Loan, Member
from .permissions import IsStaffOrReadOnly
from .serializers import (
    BookSerializer,
    LoanCreateSerializer,
    LoanSerializer,
    MemberSerializer,
)


class BookViewSet(viewsets.ModelViewSet):
    serializer_class = BookSerializer
    permission_classes = [IsStaffOrReadOnly]

    def get_queryset(self):
        queryset = Book.objects.all().order_by("title", "id")
        author = self.request.query_params.get("author")
        if author:
            queryset = queryset.filter(author__icontains=author)
        if self.request.query_params.get("available") == "true":
            queryset = [book for book in queryset if services.available_copies(book) > 0]
        return queryset

    def destroy(self, request, *args, **kwargs):
        book = self.get_object()
        if book.loans.exists():
            return Response(
                {"detail": "Books with loan history cannot be deleted."},
                status=status.HTTP_409_CONFLICT,
            )
        book.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MemberViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.CreateModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet,
):
    queryset = Member.objects.all().order_by("name", "id")
    serializer_class = MemberSerializer


class LoanViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    serializer_class = LoanSerializer

    def get_queryset(self):
        queryset = Loan.objects.select_related("book", "member").order_by("due_date", "id")
        member_id = self.request.query_params.get("member_id")
        if member_id:
            queryset = queryset.filter(member_id=member_id)
        loan_status = self.request.query_params.get("status")
        if loan_status:
            queryset = services.filter_by_status(queryset, loan_status)
        return queryset

    def create(self, request):
        serializer = LoanCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            loan = services.borrow_book(
                serializer.validated_data["member"],
                serializer.validated_data["book"],
            )
        except services.LoanError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(LoanSerializer(loan).data, status=status.HTTP_200_OK)

    @action(detail=True, methods=["post"], url_path="return")
    def return_book(self, request, pk=None):
        loan = self.get_object()
        try:
            loan = services.return_loan(loan)
        except services.LoanError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(LoanSerializer(loan).data, status=status.HTTP_200_OK)
