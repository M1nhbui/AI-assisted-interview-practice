from rest_framework.routers import DefaultRouter

from .views import BookViewSet, LoanViewSet, MemberViewSet

router = DefaultRouter()
router.register("books", BookViewSet, basename="book")
router.register("members", MemberViewSet, basename="member")
router.register("loans", LoanViewSet, basename="loan")

urlpatterns = router.urls
