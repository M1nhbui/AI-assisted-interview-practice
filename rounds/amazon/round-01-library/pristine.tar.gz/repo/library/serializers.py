from rest_framework import serializers

from . import services
from .models import Book, Loan, Member


class BookSerializer(serializers.ModelSerializer):
    available_copies = serializers.SerializerMethodField()

    class Meta:
        model = Book
        fields = [
            "id",
            "title",
            "author",
            "isbn",
            "published_year",
            "total_copies",
            "available_copies",
            "created_at",
        ]
        read_only_fields = ["id", "created_at"]

    def get_available_copies(self, obj):
        return services.available_copies(obj)

    def validate_isbn(self, value):
        if len(value) != 13 or not value.isdigit():
            raise serializers.ValidationError("ISBN must be exactly 13 digits.")
        return value

    def validate_total_copies(self, value):
        if value < 1:
            raise serializers.ValidationError("A book must have at least one copy.")
        return value


class MemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = Member
        fields = ["id", "name", "email", "is_active", "max_loans", "joined_on"]
        read_only_fields = ["id", "joined_on"]


class LoanSerializer(serializers.ModelSerializer):
    book_title = serializers.CharField(source="book.title", read_only=True)
    member_name = serializers.CharField(source="member.name", read_only=True)
    status = serializers.SerializerMethodField()

    class Meta:
        model = Loan
        fields = [
            "id",
            "book",
            "book_title",
            "member",
            "member_name",
            "borrowed_on",
            "due_date",
            "returned_on",
            "late_fee",
            "status",
        ]
        read_only_fields = fields

    def get_status(self, obj):
        return services.loan_status(obj)


class LoanCreateSerializer(serializers.Serializer):
    book = serializers.PrimaryKeyRelatedField(queryset=Book.objects.all())
    member = serializers.PrimaryKeyRelatedField(queryset=Member.objects.all())
