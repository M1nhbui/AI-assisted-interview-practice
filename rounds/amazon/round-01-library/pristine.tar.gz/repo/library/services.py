from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from .models import Book, Loan


class LoanError(Exception):
    pass


def active_loans(queryset=None):
    queryset = Loan.objects.all() if queryset is None else queryset
    return queryset.filter(returned_on__isnull=True)


def available_copies(book):
    on_loan = book.loans.filter(returned_on__isnull=False).count()
    return book.total_copies - on_loan


def loan_status(loan, today=None):
    today = today or timezone.localdate()
    if loan.returned_on is not None:
        return "returned"
    if loan.due_date < today:
        return "overdue"
    return "active"


def filter_by_status(queryset, status, today=None):
    today = today or timezone.localdate()
    if status == "returned":
        return queryset.filter(returned_on__isnull=False)
    if status == "overdue":
        return queryset.filter(returned_on__isnull=True, due_date__lt=today)
    if status == "active":
        return queryset.filter(returned_on__isnull=True, due_date__gte=today)
    return queryset


def borrow_book(member, book):
    with transaction.atomic():
        book = Book.objects.select_for_update().get(pk=book.pk)
        if not member.is_active:
            raise LoanError("Member account is inactive.")
        if active_loans(member.loans.all()).count() > member.max_loans:
            raise LoanError("Member has reached their loan limit.")
        if available_copies(book) <= 0:
            raise LoanError("No copies of this book are available.")
        today = timezone.localdate()
        return Loan.objects.create(
            book=book,
            member=member,
            borrowed_on=today,
            due_date=today + timedelta(days=settings.LIBRARY_LOAN_PERIOD_DAYS),
        )


def calculate_late_fee(due_date, returned_on):
    days_late = (returned_on - due_date).days
    if days_late <= 0:
        return Decimal("0.00")
    return Decimal(settings.LIBRARY_LATE_FEE_PER_DAY) * days_late


def return_loan(loan):
    if loan.returned_on is not None:
        raise LoanError("This loan has already been returned.")
    loan.returned_on = timezone.localdate()
    loan.late_fee = calculate_late_fee(loan.due_date, loan.returned_on)
    loan.save(update_fields=["returned_on", "late_fee"])
    return loan
