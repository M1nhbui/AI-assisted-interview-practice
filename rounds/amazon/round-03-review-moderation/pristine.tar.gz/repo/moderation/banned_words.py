BANNED_WORDS = frozenset(
    {
        "counterfeit",
        "ripoff",
        "scam",
        "spam",
    }
)
