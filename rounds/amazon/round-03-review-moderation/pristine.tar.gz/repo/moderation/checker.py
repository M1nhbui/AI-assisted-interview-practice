import re

from .banned_words import BANNED_WORDS

WORD_PATTERN = re.compile(r"[a-z']+")


def tokenize(text):
    return set(WORD_PATTERN.findall(text))


def find_banned_words(text):
    if not text:
        return []
    return sorted(tokenize(text) & BANNED_WORDS)
