# Architecture

## Layout

```
config/                 Django project: settings, root URLs
reviews/                the reviews app
  models.py             Member, Product, Review, Violation
  serializers.py        request validation and response shapes
  views.py              one APIView per URL, runs the checks in the order the README lists
  urls.py               routes under /api/
  auth.py               reads X-User-Id, decides whether a member is blocked
  services.py           writes: create and update reviews, record violations
moderation/             the content checker, shared code with no Django dependency
  banned_words.py       the banned word list
  checker.py            find_banned_words(text) -> sorted list of banned words in text
tests/                  pytest-django tests
```

## Models

- `Member`: `username`, `violation_count` (starts at 0), `is_flagged` (starts false).
- `Product`: `name`.
- `Review`: `product`, `author` (a Member), `rating` 1 to 5, `body`, `created_at`, `updated_at` (set on every save).
- `Violation`: `member`, `review` (null for a rejected create), `action` (`create` or `edit`), `words` (JSON list), `created_at`.

## Request flows

Post a review (`POST /api/products/{id}/reviews/`):

1. `auth.resolve_member` turns the header into a Member, or the view returns 401.
2. The product is loaded, or 404.
3. `auth.is_blocked` is asked whether the member may write; if not, 403 `account is flagged`.
4. `ReviewCreateSerializer` validates `rating` and `body`, or 400.
5. `moderation.checker.find_banned_words` checks the body. If it finds words, `services.record_violation` stores the violation, adds 1 to the member's count and flags them at the threshold, and the view returns 403.
6. Otherwise `services.create_review` saves the review and the view returns 201.

Edit a review (`PATCH /api/reviews/{id}/`): same idea. Auth, load the review, check the caller is the author, check `is_blocked`, validate with `ReviewUpdateSerializer`, then, if a new body was sent, run the checker on it. A violation here is recorded with `action = "edit"` and the review. Clean changes go through `services.update_review`.

List reviews (`GET /api/products/{id}/reviews/`): no auth; loads the product and returns its reviews, newest first.

Moderation status (`GET /api/members/{id}/moderation/`): auth, the caller must be the member, then returns the count, the flag and the violations newest first.
