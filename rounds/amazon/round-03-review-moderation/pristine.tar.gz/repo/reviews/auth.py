from django.conf import settings

from .models import Member

USER_HEADER = "X-User-Id"


def resolve_member(request):
    raw = request.headers.get(USER_HEADER, "").strip()
    if not raw.isdigit():
        return None
    return Member.objects.filter(pk=int(raw)).first()


def is_blocked(member):
    return member.violation_count > settings.FLAG_AFTER_VIOLATIONS
