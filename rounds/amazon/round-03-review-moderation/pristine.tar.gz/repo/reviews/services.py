from django.conf import settings
from django.db import transaction
from django.db.models import F

from .models import Member, Review, Violation


def create_review(product, author, rating, body):
    return Review.objects.create(
        product=product, author=author, rating=rating, body=body
    )


def update_review(review, changes):
    for field_name, value in changes.items():
        setattr(review, field_name, value)
    review.save()
    return review


@transaction.atomic
def record_violation(member, words, action, review=None):
    Violation.objects.create(
        member=member, review=review, action=action, words=list(words)
    )
    Member.objects.filter(pk=member.pk).update(
        violation_count=F("violation_count") + 1
    )
    if member.violation_count >= settings.FLAG_AFTER_VIOLATIONS:
        Member.objects.filter(pk=member.pk).update(is_flagged=True)
