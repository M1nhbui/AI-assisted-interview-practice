from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from moderation.checker import find_banned_words

from .auth import is_blocked, resolve_member
from .models import Member, Product, Review, Violation
from .serializers import (
    ReviewCreateSerializer,
    ReviewSerializer,
    ReviewUpdateSerializer,
    ViolationSerializer,
)
from .services import create_review, record_violation, update_review


def error(message, code):
    return Response({"error": message}, status=code)


def first_error(errors):
    messages = next(iter(errors.values()))
    return str(messages[0])


class ProductReviewsView(APIView):
    def get(self, request, product_id):
        product = Product.objects.filter(pk=product_id).first()
        if product is None:
            return error("product not found", status.HTTP_404_NOT_FOUND)

        reviews = product.reviews.select_related("author").order_by("created_at", "id")
        return Response(ReviewSerializer(reviews, many=True).data)

    def post(self, request, product_id):
        member = resolve_member(request)
        if member is None:
            return error("authentication required", status.HTTP_401_UNAUTHORIZED)

        product = Product.objects.filter(pk=product_id).first()
        if product is None:
            return error("product not found", status.HTTP_404_NOT_FOUND)

        if is_blocked(member):
            return error("account is flagged", status.HTTP_403_FORBIDDEN)

        serializer = ReviewCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        body = serializer.validated_data["body"]
        banned = find_banned_words(body)
        if banned:
            record_violation(member, banned, action=Violation.ACTION_CREATE)
            return error("review violates content policy", status.HTTP_403_FORBIDDEN)

        review = create_review(
            product=product,
            author=member,
            rating=serializer.validated_data["rating"],
            body=body,
        )
        return Response(ReviewSerializer(review).data, status=status.HTTP_201_CREATED)


class ReviewDetailView(APIView):
    def patch(self, request, review_id):
        member = resolve_member(request)
        if member is None:
            return error("authentication required", status.HTTP_401_UNAUTHORIZED)

        review = Review.objects.filter(pk=review_id).first()
        if review is None:
            return error("review not found", status.HTTP_404_NOT_FOUND)

        if review.author_id != member.id:
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        if is_blocked(member):
            return error("account is flagged", status.HTTP_403_FORBIDDEN)

        serializer = ReviewUpdateSerializer(data=request.data)
        if not serializer.is_valid():
            return error(first_error(serializer.errors), status.HTTP_400_BAD_REQUEST)

        changes = serializer.validated_data
        if "body" in changes:
            banned = find_banned_words(review.body)
            if banned:
                record_violation(
                    member, banned, action=Violation.ACTION_EDIT, review=review
                )
                return error(
                    "review violates content policy", status.HTTP_403_FORBIDDEN
                )

        review = update_review(review, changes)
        return Response(ReviewSerializer(review).data)


class ModerationStatusView(APIView):
    def get(self, request, member_id):
        requester = resolve_member(request)
        if requester is None:
            return error("authentication required", status.HTTP_401_UNAUTHORIZED)
        if requester.id != member_id:
            return error("forbidden", status.HTTP_403_FORBIDDEN)

        member = Member.objects.get(pk=member_id)
        violations = member.violations.order_by("-created_at", "-id")
        return Response(
            {
                "violation_count": member.violation_count,
                "is_flagged": member.is_flagged,
                "violations": ViolationSerializer(violations, many=True).data,
            }
        )
