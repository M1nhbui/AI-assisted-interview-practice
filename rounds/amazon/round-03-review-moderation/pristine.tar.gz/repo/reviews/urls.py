from django.urls import path

from .views import ModerationStatusView, ProductReviewsView, ReviewDetailView

urlpatterns = [
    path(
        "products/<int:product_id>/reviews/",
        ProductReviewsView.as_view(),
        name="product-reviews",
    ),
    path("reviews/<int:review_id>/", ReviewDetailView.as_view(), name="review-detail"),
    path(
        "members/<int:member_id>/moderation/",
        ModerationStatusView.as_view(),
        name="moderation-status",
    ),
]
