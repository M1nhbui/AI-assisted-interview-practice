from rest_framework import serializers

from .models import Review, Violation

RATING_ERRORS = {
    "required": "rating is required",
    "null": "rating is required",
    "invalid": "rating must be between 1 and 5",
    "min_value": "rating must be between 1 and 5",
    "max_value": "rating must be between 1 and 5",
}

BODY_ERRORS = {
    "required": "body is required",
    "null": "body is required",
    "blank": "body is required",
    "max_length": "body must be at most 2000 characters",
}


class ReviewCreateSerializer(serializers.Serializer):
    rating = serializers.IntegerField(
        min_value=1, max_value=5, error_messages=RATING_ERRORS
    )
    body = serializers.CharField(max_length=2000, error_messages=BODY_ERRORS)


class ReviewUpdateSerializer(serializers.Serializer):
    rating = serializers.IntegerField(
        min_value=1, max_value=5, required=False, error_messages=RATING_ERRORS
    )
    body = serializers.CharField(
        max_length=2000, required=False, error_messages=BODY_ERRORS
    )

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError("rating or body is required")
        return attrs


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ["id", "product", "author", "rating", "body", "created_at", "updated_at"]


class ViolationSerializer(serializers.ModelSerializer):
    review_id = serializers.IntegerField(allow_null=True)

    class Meta:
        model = Violation
        fields = ["review_id", "action", "words", "created_at"]
