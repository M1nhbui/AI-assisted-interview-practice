from django.db import models
from django.utils import timezone


class Member(models.Model):
    username = models.CharField(max_length=50, unique=True)
    violation_count = models.PositiveIntegerField(default=0)
    is_flagged = models.BooleanField(default=False)
    joined_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.username


class Product(models.Model):
    name = models.CharField(max_length=120)

    def __str__(self):
        return self.name


class Review(models.Model):
    product = models.ForeignKey(
        Product, related_name="reviews", on_delete=models.CASCADE
    )
    author = models.ForeignKey(
        Member, related_name="reviews", on_delete=models.CASCADE
    )
    rating = models.PositiveSmallIntegerField()
    body = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Review {self.pk} of {self.product_id} by {self.author_id}"


class Violation(models.Model):
    ACTION_CREATE = "create"
    ACTION_EDIT = "edit"
    ACTION_CHOICES = [
        (ACTION_CREATE, "Create review"),
        (ACTION_EDIT, "Edit review"),
    ]

    member = models.ForeignKey(
        Member, related_name="violations", on_delete=models.CASCADE
    )
    review = models.ForeignKey(
        Review,
        related_name="violations",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
    words = models.JSONField(default=list)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Violation {self.pk} by {self.member_id}"
