from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from reviews.models import Member, Product, Review


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def make_member(db):
    def _make_member(username, **overrides):
        return Member.objects.create(username=username, **overrides)

    return _make_member


@pytest.fixture
def alice(make_member):
    return make_member("alice")


@pytest.fixture
def bob(make_member):
    return make_member("bob")


@pytest.fixture
def product(db):
    return Product.objects.create(name="Trail Backpack 30L")


@pytest.fixture
def make_review(db):
    def _make_review(product, author, rating=4, body="Does the job.", age_minutes=0):
        return Review.objects.create(
            product=product,
            author=author,
            rating=rating,
            body=body,
            created_at=timezone.now() - timedelta(minutes=age_minutes),
        )

    return _make_review


def as_member(member):
    return {"HTTP_X_USER_ID": str(member.id)}
