from reviews.models import Product, Review

from .conftest import as_member


def reviews_url(product):
    return f"/api/products/{product.id}/reviews/"


def test_create_review(api_client, alice, product):
    payload = {"rating": 5, "body": "Sturdy straps and plenty of pockets."}

    response = api_client.post(
        reviews_url(product), payload, format="json", **as_member(alice)
    )

    assert response.status_code == 201
    body = response.json()
    assert body["product"] == product.id
    assert body["author"] == alice.id
    assert body["rating"] == 5
    assert body["body"] == "Sturdy straps and plenty of pockets."
    saved = Review.objects.get(pk=body["id"])
    assert saved.author == alice
    assert saved.product == product

    anonymous = api_client.post(reviews_url(product), payload, format="json")
    assert anonymous.status_code == 401
    assert anonymous.json() == {"error": "authentication required"}
    assert Review.objects.count() == 1


def test_list_reviews_newest_first(api_client, alice, bob, product, make_review):
    older = make_review(product, alice, body="Held up on a week-long hike.", age_minutes=90)
    newer = make_review(product, bob, body="Zipper feels a bit stiff.", age_minutes=5)
    other_product = Product.objects.create(name="Camp Stove")
    make_review(other_product, alice, body="Boils water fast.")

    response = api_client.get(reviews_url(product))

    assert response.status_code == 200
    assert [review["id"] for review in response.json()] == [newer.id, older.id]


def test_flagged_member_cannot_post(api_client, make_member, product):
    flagged = make_member("mallory", violation_count=3, is_flagged=True)

    response = api_client.post(
        reviews_url(product),
        {"rating": 4, "body": "Nice colour options."},
        format="json",
        **as_member(flagged),
    )

    assert response.status_code == 403
    assert response.json() == {"error": "account is flagged"}
    assert Review.objects.count() == 0
