from reviews.models import Review, Violation

from .conftest import as_member


def reviews_url(product):
    return f"/api/products/{product.id}/reviews/"


def test_banned_review_is_blocked_and_recorded(api_client, alice, product):
    response = api_client.post(
        reviews_url(product),
        {"rating": 1, "body": "Total ripoff, this listing is a scam."},
        format="json",
        **as_member(alice),
    )

    assert response.status_code == 403
    assert response.json() == {"error": "review violates content policy"}
    assert Review.objects.count() == 0

    alice.refresh_from_db()
    assert alice.violation_count == 1
    assert alice.is_flagged is False
    violation = Violation.objects.get(member=alice)
    assert violation.action == "create"
    assert violation.review is None
    assert violation.words == ["ripoff", "scam"]


def test_third_violation_flags_member(api_client, alice, product):
    for _ in range(3):
        response = api_client.post(
            reviews_url(product),
            {"rating": 1, "body": "spam spam spam"},
            format="json",
            **as_member(alice),
        )
        assert response.status_code == 403
        assert response.json() == {"error": "review violates content policy"}

    alice.refresh_from_db()
    assert alice.violation_count == 3
    assert alice.is_flagged is True

    clean = api_client.post(
        reviews_url(product),
        {"rating": 5, "body": "Actually it is great."},
        format="json",
        **as_member(alice),
    )
    assert clean.status_code == 403
    assert clean.json() == {"error": "account is flagged"}
    alice.refresh_from_db()
    assert alice.violation_count == 3


def test_edit_with_banned_words_is_blocked(api_client, alice, product, make_review):
    review = make_review(product, alice, body="Works fine for day trips.")

    response = api_client.patch(
        f"/api/reviews/{review.id}/",
        {"body": "Honestly a scam."},
        format="json",
        **as_member(alice),
    )

    assert response.status_code == 403
    assert response.json() == {"error": "review violates content policy"}
    review.refresh_from_db()
    assert review.body == "Works fine for day trips."
    alice.refresh_from_db()
    assert alice.violation_count == 1
    violation = Violation.objects.get(member=alice)
    assert violation.action == "edit"
    assert violation.review_id == review.id
    assert violation.words == ["scam"]
