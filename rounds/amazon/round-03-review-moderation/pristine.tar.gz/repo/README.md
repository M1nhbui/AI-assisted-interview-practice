# Product Reviews Service

A small JSON API for product reviews with built-in content moderation. Members post reviews on products and edit their own reviews. Each review body is checked against a list of banned words before it is saved. Rejected attempts are recorded as violations, and a member who collects too many violations is flagged.

There is no frontend and no login flow. The caller identifies themselves with the `X-User-Id` header.

## Requirements

- Python 3.11 or newer
- The packages in `requirements.txt` (Django 5.2, Django REST Framework, pytest, pytest-django)

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
```

## Running the server

```bash
python manage.py runserver
curl -H "Content-Type: application/json" -H "X-User-Id: 1" \
     -d '{"rating": 5, "body": "Great pack."}' \
     http://127.0.0.1:8000/api/products/1/reviews/
```

## Running the tests

```bash
./t                                         # whole suite
./t tests/test_reviews.py                   # one file
./t tests/test_reviews.py::test_create_review
./t -k flagged                              # by name
```

`./t` runs pytest with any arguments you pass and appends a one-line summary to `../test_runs.log`.

## Content policy

- The banned words are listed in `moderation/banned_words.py`.
- Matching is case-insensitive and whole-word: `Scam` and `SCAM` match `scam`, but `scampi` does not.
- A review body that contains at least one banned word is rejected. Nothing is created or changed.
- Every rejected attempt (create or edit) is recorded as one violation. The violation stores the action (`create` or `edit`), the review it was about (`null` for a create), and the banned words found: lowercase, each word once, sorted alphabetically.
- Each violation adds 1 to the member's `violation_count`.
- A member is flagged (`is_flagged = true`) as soon as their `violation_count` reaches 3 (`FLAG_AFTER_VIOLATIONS` in settings). The flag is saved on the member.
- Only `is_flagged` decides whether a member is blocked. Moderators can also flag or unflag members directly in the database; a member with `is_flagged = false` is never blocked, whatever their `violation_count`.
- A flagged member cannot create or edit reviews.

## API contract

All endpoints live under `/api/` and accept and return JSON. Errors always have the body `{"error": "<message>"}` with the exact message listed below. When a request has several problems, the checks run in the order listed for that endpoint, and the first failing check decides the response.

A review is returned as:

```json
{"id": 1, "product": 3, "author": 7, "rating": 5, "body": "Great pack.", "created_at": "<ISO 8601>", "updated_at": "<ISO 8601>"}
```

### GET /api/products/{id}/reviews/

List the reviews of one product, newest first (by `created_at`; reviews with the same `created_at` are ordered by `id`, highest first).

- Required headers: none
- Success: `200` with a JSON list of reviews
- Errors:
  - `404` `product not found`

### POST /api/products/{id}/reviews/

Post a review.

- Required fields: `rating` (integer 1 to 5), `body` (non-blank text, at most 2000 characters)
- Required headers: `X-User-Id: <member id>`
- Success: `201` with the new review
- Errors, in order:
  - `401` `authentication required` when the header is missing, is not a number, or does not match a member
  - `404` `product not found`
  - `403` `account is flagged`
  - `400` `rating is required`, `rating must be between 1 and 5`, `body is required`, or `body must be at most 2000 characters`
  - `403` `review violates content policy` (a violation is recorded; no review is created)

### PATCH /api/reviews/{id}/

Edit your own review. Send `rating`, `body`, or both. Only the fields sent are changed.

- Required headers: `X-User-Id: <member id>`
- Success: `200` with the updated review
- Errors, in order:
  - `401` `authentication required`
  - `404` `review not found`
  - `403` `forbidden` when the caller is not the review's author
  - `403` `account is flagged`
  - `400` `rating or body is required` when neither field is sent, or a field error from the list above
  - `403` `review violates content policy` when the new `body` contains a banned word (a violation is recorded with this review; the review is not changed)

### GET /api/members/{id}/moderation/

A member's own moderation status.

- Required headers: `X-User-Id: <member id>`
- Success: `200` with `{"violation_count": <int>, "is_flagged": <bool>, "violations": [{"review_id": <int or null>, "action": "create" | "edit", "words": ["..."], "created_at": "<ISO 8601>"}]}`, violations newest first
- Errors:
  - `401` `authentication required`
  - `403` `forbidden` when the caller is not member `{id}`
