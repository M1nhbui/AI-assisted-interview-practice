# Task: Product Reviews Service

This repository contains a small JSON API for product reviews on an outdoor-gear marketplace. Members post and edit reviews. Every new or edited review passes through the existing content checker; reviews that contain banned words are rejected, the attempt is recorded as a violation, and members who reach three violations are flagged and can no longer post or edit reviews.

The trust and safety team has received several complaints since the last release.

## Reported issues

- Members can get banned words published by editing a review after it was posted.
- Members who break the content policy three times are not flagged.
- Flagged members can still post reviews.

Pass as many tests as possible. Behavior must follow the API contract in README.md.
